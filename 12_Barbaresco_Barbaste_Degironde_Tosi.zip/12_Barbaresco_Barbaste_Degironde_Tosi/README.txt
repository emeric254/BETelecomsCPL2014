/**********************************
 * Objet : Contenu du dossier     *
 * Groupe 12 : BARBARESCO Lo�c    *
 *             BARBASTE R�mi      *
 *             DEGIRONDE Robin    *
 *             TOSE Emeric        *
 **********************************/

Ce dossier contient :
  - La pr�sentation powerpoint de notre BE sur les CPL.
  - Le rapport sur les CPL.
  - Le rapport sur les filtres.
  - Un lien vers le site internet de l'application de l'outil de calcul de filtre de Tchebychev.
  - Fichiers necessaire pour lancer l'outil sans connexion internet.


Pour faire fonctionner notre outil de calcul de filtres de Tchebychev, veuillez simplement ouvrir 
le fichier �index.html�, pr�sent dans le dossier �Source filtres�, avec votre navigateur web pr�f�r�.

Pour consulter ce site depuis n'importe o�, cliquez sur le raccourci internet �Calcul de filtres� ou allez � l'URL suivante :
http://emeric254.github.io/BETelecomsCPL2014/ 


